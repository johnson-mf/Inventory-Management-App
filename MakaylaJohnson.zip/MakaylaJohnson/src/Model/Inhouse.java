package Model;
//InhousePart is a subclass of the Part class



/** This is the Inhouse class member. It extends the Part class. The machine ID is a field that is unique to inhouse part class*/
public class Inhouse extends Part{


    private int machineId;

    public Inhouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        //must use "super" and use Parts' constructors
        super(id, name, price, stock, min, max);
        //int machineid is initialized here since it is specific to inhouse parts
        this.machineId = machineId;
    }

    public int getMachineId() {

        return machineId;
    }

    public void setMachineId(int machineId) {

        this.machineId = machineId;
    }
}
