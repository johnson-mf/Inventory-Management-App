package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
/** This is the Inventory class member. It stores parts and products, and all the static members are found here. Set, get, update, delete, and adding parts and products is done from here. */
public class Inventory {
    // Creating the observable array lists
    public static int partId = 1;
    public static int productId = 1;


    // PARTS
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Part> filteredParts = FXCollections.observableArrayList();

    public static void addPart(Part part) {
        allParts.add(part);

    }

    public static ObservableList<Part> getAllParts() {

        return allParts;
    }

    public static ObservableList<Part> getFilteredParts() {

        return filteredParts;
    }

    public static Part lookupPart(int partId) {

        ObservableList<Part> allParts = Inventory.getAllParts();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        for (Part part : allParts) {
            if (part.getId() == partId)
                return part;

        }
        return null;
    }

    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> allParts = Inventory.getAllParts();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        for (Part part : allParts) {
            if (part.getName().contains(partName)) {
                filteredParts.add(part);
            }
        }
        return filteredParts;

    }
    /** LOGICAL ERROR: Index and the ID assigned to the part ID sometimes did not match. counting up from the same number and incrementing up solved this issue*/
    public static void updatePart(int index, Part selectedPart) {
        index = 1;

        for (Part part : Inventory.getAllParts()) {



            if (part.getId() == index) {

                Inventory.getAllParts().set(index, selectedPart);


            }

            index++;

        }


    }



    // PRODUCTS
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    public static void addProduct(Product product) {
        allProducts.add(product);
    }

    public static Product lookupProduct(int productId) {

        ObservableList<Product> allProducts = Inventory.getAllProducts();
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();

        for (Product product : allProducts) {
            if (product.getId() == productId)
                return product;

        }
        return null;
    }

    public static ObservableList<Product> lookupProduct(String productName) {

        ObservableList<Product> allProducts = Inventory.getAllProducts();
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();

        for (Product product : allProducts) {
            if (product.getName().contains(productName)) {
                filteredProducts.add(product);
            }
        }
        return filteredProducts;
    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    public static void setAllProducts(ObservableList<Product> allProducts) {
        Inventory.allProducts = allProducts;
    }

    public static void updateProduct(int index, Product selectedProduct) {
        index = 1;

        for (Product product : Inventory.getAllProducts()) {



            if (product.getId() == index) {

                Inventory.getAllProducts().set(index, selectedProduct);


            }
            index++;

        }


    }
}