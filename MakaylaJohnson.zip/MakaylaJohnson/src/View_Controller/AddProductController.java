package View_Controller;

import Model.Inhouse;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**This is the add product screen. Users and add a part and assign it's fields for the
 * name, stock, max, min, and price. The ID is automatically generated and cannot be changed by the user. You then can add
 * parts that have been already created, and add them to the associated parts list for the product that the user is making.
 *  If a part is added on accident, the user has the option to delete it before saving.  */
public class AddProductController implements Initializable {
    Stage stage;
    Parent scene;
    Product product;

    @FXML
    private TextField productIdTxt;

    @FXML
    private TextField productNameTxt;

    @FXML
    private TextField productInventoryTxt;

    @FXML
    private TextField productPriceTxt;

    @FXML
    private TextField productMaxTxt;

    @FXML
    private TextField productMinTxt;

    @FXML
    private TextField partSearchTxt;


    @FXML
    private TableView<Part> partTableView;

    @FXML
    private TableColumn<Part, Integer> partIdCol;

    @FXML
    private TableColumn<Part, String> partNameCol;

    @FXML
    private TableColumn<Part, Integer> partInventoryCol;

    @FXML
    private TableColumn<Part, Double> partPriceCol;


    @FXML
    private TableView<Part> associatedPartsTableView;

    @FXML
    private TableColumn<Part, Integer> associatedPartIdCol;

    @FXML
    private TableColumn<Part, String> associatedPartNameCol;

    @FXML
    private TableColumn<Part, Integer> associatedPartInventoryCol;

    @FXML
    private TableColumn<Part, Double> associatedPartPriceCol;

    @FXML
    private Label warningLabel;

    @FXML
    void onActionAddPartToProduct(ActionEvent event) {
       // get the parts that have been selected

        ObservableList<Part> selectedRows, allParts;
        allParts = partTableView.getItems();
        selectedRows = partTableView.getSelectionModel().getSelectedItems();

        // create a new list to place those parts in

        //ObservableList<Part> associatedPart = FXCollections.observableArrayList();

        for(Part part : selectedRows){
            product.addAssociatedPart(part);
        }
    }

    @FXML
    void onActionRemoveSelectedPart(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete the associated part?");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }

        // get the parts that have been selected
        ObservableList<Part> selectedRows, allParts;
        allParts = associatedPartsTableView.getItems();
        selectedRows = associatedPartsTableView.getSelectionModel().getSelectedItems();

        // create a new list to place those parts in

        //ObservableList<Part> associatedPart = FXCollections.observableArrayList();

        for(Part part : selectedRows){
            product.deleteAssociatedPart(part);
        }
    }

    private Part getAllParts(int userId){

        ObservableList<Part> allParts = FXCollections.observableArrayList();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        for (Part part : Inventory.getAllParts()){
            if (part.getId() == userId)
                return part;

        }
        return null;

    }

    private ObservableList<Part> lookupPart (String partialName){
        ObservableList<Part> allParts = FXCollections.observableArrayList();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        for (Part part : Inventory.getAllParts()){
            if (part.getName().contains(partialName)){
                filteredParts.add(part);
            }
        }
        return filteredParts;

    }
    @FXML
    void onActionLookupPart(ActionEvent event) {
        String q = partSearchTxt.getText();
        // we will search by part name first:
        ObservableList<Part> parts = lookupPart(q);

        // if it returns with nothing from the above search, it will search by id
        if(parts.size() == 0){

            //turn the input into a number
            int userID = Integer.parseInt(q);

            //the variable newPart will be assigned to inputted user id and make sure its not null
            Part newPart = getAllParts(userID);

            if(newPart != null){
                parts.add(newPart);
            }

        }
        partTableView.setItems(parts);

    }


    @FXML
    void onActionDisplayMainMenu(ActionEvent event) throws IOException {
        //Confirmation dialog box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear text fields, Do you want to continue?");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();

        //If they press OK, we go back to main screen.

        if(result.isPresent() && result.get() == ButtonType.OK) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

    }


    @FXML
    void onActionSaveProduct(ActionEvent event) {

        //Taking in text fields and turning them into the appropriate type
        //exception if you enter incorrect data types
        try {


            int id = Inventory.productId++;
            String name = productNameTxt.getText();
            double price = Double.parseDouble(productPriceTxt.getText());
            int stock = Integer.parseInt(productInventoryTxt.getText());
            int min = Integer.parseInt(productMinTxt.getText());
            int max = Integer.parseInt(productMaxTxt.getText());

            if (min <= max && stock <= max && min <= stock) {
                    product.setId(id);
                    product.setMax(max);
                    product.setMin(min);
                    product.setName(name);
                    product.setStock(stock);

                    Inventory.addProduct(product);


                //clear associated parts once finished
                //Product.getAssociatedParts().clear();
                // once saved, takes to main screen
                    stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
                    stage.setScene(new Scene(scene));
                    stage.show();
            }
            warningLabel.setText("The inventory number must be a number between the min and max values you enter!");
        }
        catch(NumberFormatException | IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Wrong Data Type");
            alert.setContentText("Please enter values that correspond with their fields!");
            alert.showAndWait();
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Telling which observable list to throw into the program everytime it starts
        partTableView.setItems(Inventory.getAllParts());


        //create a dummy product
        product = new Product(0,null,0,0,0,0);

        //Telling it where to place the values in the table
        //Everytime the Observable List is created, all of these fields will be initialized

        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        associatedPartsTableView.setItems(product.getAllAssociatedParts());

        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


    }
}
