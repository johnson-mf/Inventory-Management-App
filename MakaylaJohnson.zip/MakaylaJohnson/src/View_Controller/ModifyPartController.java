package View_Controller;

import Model.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**This is the modify product screen. The text fields will be pre-populated and the ID will not be changed.
 * The user can change the values in these fields as long as the obey the data type rules. Fields for the fields for the
 *name, stock, max, min, and price are all available for changing.When an Inhouse part is selected, the Machine ID field appears.
 * If it is outsourced, the Company name field will appear.
 * Cancelling will prompt a window asking if the user would like to delete all text fields and go back to the main screen */
public class ModifyPartController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private Label variableLabel;

    @FXML
    private Label partIdTxt;

    @FXML
    private TextField partNameTxt;

    @FXML
    private TextField partInventoryTxt;

    @FXML
    private TextField partPriceTxt;

    @FXML
    private TextField partMaxTxt;

    @FXML
    private TextField partMachineIdTxt;

    @FXML
    private RadioButton partInhouseLBtn;

    @FXML
    private ToggleGroup AddPartTG;

    @FXML
    private RadioButton partOutsourcedRBtn;

    @FXML
    private TextField partMinTxt;

    @FXML
    private Label warningLabel;

    @FXML
    void onActionDisplayMainMenu(ActionEvent event) throws IOException {

        stage = (Stage) ((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void onActionModifyPart(ActionEvent event) throws IOException {

        //Taking in text fields and turning them into the appropriate type
        //exception if you enter incorrect data types
        try {


            int id = Integer.parseInt(partIdTxt.getText());
            String name = partNameTxt.getText();
            double price = Double.parseDouble(partPriceTxt.getText());
            int stock = Integer.parseInt(partInventoryTxt.getText());
            int min = Integer.parseInt(partMinTxt.getText());
            int max = Integer.parseInt(partMaxTxt.getText());

            delete(id);

            if (min <= max && stock <= max && min <= stock) {
                if (partInhouseLBtn.isSelected()) {
                    int machineId = Integer.parseInt(partMachineIdTxt.getText());
                    Inventory.addPart(new Inhouse(id, name, price, stock, min, max, machineId));
                } else {

                    String companyName = partMachineIdTxt.getText();
                    Inventory.addPart(new Outsourced(id, name, price, stock, min, max, companyName));
                }
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }



        warningLabel.setText("The inventory number must be a number between the min and max values you enter!");
    }

        catch(NumberFormatException | IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Enter letters for names and numbers for number fields!");
            alert.showAndWait();
        }
    }


    @FXML
    void onMouseClickInhouse(MouseEvent event) {
        variableLabel.setText("Machine ID:");
    }

    @FXML
    void OnMouseClickOutsourced(MouseEvent event) {
        variableLabel.setText("Company Name:");
    }

    //Setting the text box id in the modify part screen with a pre filled entry
    public void sendPart(Part part){

        partIdTxt.setText(String.valueOf(part.getId()));
        partNameTxt.setText(part.getName());
        partInventoryTxt.setText(String.valueOf(part.getStock()));
        partPriceTxt.setText(String.valueOf(part.getPrice()));
        partMaxTxt.setText(String.valueOf(part.getMax()));
        partMinTxt.setText(String.valueOf(part.getMin()));
   ///Must cast the machine id since it is from a subclass
        if(part instanceof Inhouse) {
            partMachineIdTxt.setText(String.valueOf(((Inhouse) part).getMachineId()));
            partInhouseLBtn.setSelected(true);
        }
        else{
            partMachineIdTxt.setText(String.valueOf(((Outsourced) part).getCompanyName()));
            partOutsourcedRBtn.setSelected(true);
        }
        /*if (inhousePart.)
            isInhouse = true;
        else
            isInhouse = false;*/
    }
    public boolean delete(int id) {
        for (Part inhousePart : Inventory.getAllParts()) {
            if (inhousePart.getId() == id) {
                return Inventory.getAllParts().remove(inhousePart);
            }
        }
        return false;

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}


