package View_Controller;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**This is the main Inventory screen. A table of products and parts are displayed on the main screen.
 * You can add, delete and modify parts and products from here. You also have the ability to search parts and products
 * using their IDs or names. Once finished, the user can exit. */
public class MainController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TableView<Part> partTableView;
    @FXML
    private TableView<Product> productTableView;
    @FXML
    private TableColumn<Part, Integer> partIdCol;

    @FXML
    private TableColumn<Part, String> partNameCol;

    @FXML
    private TableColumn<Part, Integer> partInventoryCol;

    @FXML
    private TableColumn<Part, Double> partPriceCol;

    @FXML
    private TableColumn<Product, Integer> productIdCol;

    @FXML
    private TableColumn<Product, String> productNameCol;

    @FXML
    private TableColumn<Product, Integer> productInventoryCol;

    @FXML
    private TableColumn<Product, Double> productPriceCol;

    @FXML
    private TextField productSearchTxt;

    @FXML
    private TextField partSearchTxt;

    @FXML
    private Label warningLabel;

    @FXML
    void onActionAddPart(ActionEvent event) throws IOException {
        System.out.println("Do you see me?");
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/AddPart.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    @FXML
    void onActionAddProduct(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/AddProduct.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    @FXML
    void onActionDeletePart(ActionEvent event) {
        //Confirmation dialog box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this part?");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }
        //create an empty array list and bring us our original array list,
        ObservableList<Part> selectedRows, allParts;
        allParts = partTableView.getItems();

        //give us the selected rows
        selectedRows = partTableView.getSelectionModel().getSelectedItems();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Part part : selectedRows) {
            allParts.remove(part);
        }

    }


    @FXML
    void onActionDeleteProduct(ActionEvent event) {
        //Confirmation dialog box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this product??");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK) {
        Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();

        if(selectedProduct.getAllAssociatedParts().size() == 0){
            Inventory.deleteProduct(selectedProduct);
        }
        else
            warningLabel.setText("Please delete all associated parts before deleting the product!");
    }
    }

    // GOES BACK TO MAIN
    @FXML
    void onActionDisplayMainMenu(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();


    }

    @FXML
    void onActionModifyPart(ActionEvent event) throws IOException {


        //Passing information from one controller to another

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/ModifyPart.fxml"));
        loader.load();



        ModifyPartController MPController = loader.getController();
        MPController.sendPart(partTableView.getSelectionModel().getSelectedItem());


        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        //scene = FXMLLoader.load(getClass().getResource("/View_Controller/ModifyPart.fxml"));
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void onActionModifyProduct(ActionEvent event) throws IOException {

        //Passing information from one controller to another

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/ModifyProduct.fxml"));
        loader.load();


        // load the data and send it to the table view
        ModifyProductController MPrController = loader.getController();
        MPrController.sendProduct(productTableView.getSelectionModel().getSelectedItem());


        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        //scene = FXMLLoader.load(getClass().getResource("/View_Controller/ModifyPart.fxml"));
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    //EXIT BUTTON
    @FXML
    void onActionExit(ActionEvent event) {

        System.exit(0);
    }

    //A search will be preformed on the list, and if it is found, will return true, else false.
    public boolean search(int id) {
        for (Part part : Inventory.getAllParts()) {
            if (part.getId() == id)
                return true;
        }
        return false;
    }

    //SEARCHING PART TABLE
    @FXML
    void onActionLookupPart(ActionEvent event) {
        String q = partSearchTxt.getText();
        // we will search by part name first:
        ObservableList<Part> parts = Inventory.lookupPart(q);

        // if it returns with nothing from the above search, it will search by id
        if (parts.size() == 0) {

            //turn the input into a number
            int id = Integer.parseInt(q);

            //the variable newPart will be assigned to inputted user id and make sure its not null
            Part part = Inventory.lookupPart(id);

            if (part != null) {
                parts.add(part);
            }

        }
        partTableView.setItems(parts);


    }




    private Product getAllProducts(int userId) {

        ObservableList<Product> allProducts = FXCollections.observableArrayList();
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();

        for (Product products : Inventory.getAllProducts()) {
            if (products.getId() == userId)
                return products;
        }

        return null;
    }

    //WARNING OBJECT
    private Object lookupProduct(String partialName) {
        ObservableList<Product> allProducts = FXCollections.observableArrayList();
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();

        for (Product product : Inventory.getAllProducts()) {
            if (product.getName().contains(partialName)) {
                filteredProducts.add(product);
            }
        }
        return filteredProducts;
    }

    @FXML
    void onActionLookupProduct(ActionEvent event) {


    }


    @FXML
    void onProductKeyPressed(KeyEvent event) {

        // warning label is empty
        warningLabel.setText("");

        // variable "q" is the what the user is trying to search
        String q = productSearchTxt.getText();
        ObservableList<Product> products = Inventory.lookupProduct(q);

        if (products.size() == 0) {
            warningLabel.setText("No name was found!");
            productTableView.setItems(products);


            int id = Integer.parseInt(q);

            Product product = Inventory.lookupProduct(id);
            if (product != null)
                products.add(product);
            warningLabel.setText("");
        }

        productTableView.setItems(products);
        if (products.isEmpty()) {
            warningLabel.setText("No ID was found!");
        }
    }
        @FXML
    private void onPartKeyPressed(KeyEvent event) {

        // warning label is empty
          warningLabel.setText("");

        // variable "q" is the what the user is trying to search
          String q = partSearchTxt.getText();
          ObservableList<Part> parts = Inventory.lookupPart(q);

          // set the fields they type in into the new parts array we just created. if its empty, we will convert to integer

          if (parts.size() == 0) {
              warningLabel.setText("No name was found!");
              partTableView.setItems(parts);

              int id = Integer.parseInt(q);

              Part part = Inventory.lookupPart(id);
              if (part != null)
                  parts.add(part);
              warningLabel.setText("");
          }

          partTableView.setItems(parts);

          if(parts.isEmpty()){
              warningLabel.setText("No ID was found!");
          }

    }

    @FXML

    //Update button will begin with a search, and if found, will change the
    //values in the table.

    //an unused Delete method
    public boolean delete(int id) {
        for (Part inhousePart : Inventory.getAllParts()) {
            if (inhousePart.getId() == id) {
                return Inventory.getAllParts().remove(inhousePart);
            }
        }
        return false;

    }

    //Selecting a part within a table
    public Part selectPart(int id) {

        for (Part inhousePart : Inventory.getAllParts()) {
            if (inhousePart.getId() == id) {
                return inhousePart;
            }
        }
        return null;
    }


    //FILTERING PARTS AND APPENDING THEM TO A NEW LIST

    public ObservableList<Part> filter(String name) {


        //Checking to see if the filtered list is Not empty. If it has values, it must be cleared.
        if (!(Inventory.getFilteredParts().isEmpty()))
            Inventory.getFilteredParts().clear();

        //Now we go into checking the original list for our desired item
        for (Part inhousePart : Inventory.getAllParts()) {

            //If the name is found in the list, it will add it to a new array called "filtered parts"

            if (inhousePart.getName().contains(name))
                Inventory.getFilteredParts().add(inhousePart);
        }
        //If the item is not found, we want to display all items in the original list, not an empty list.
        if (Inventory.getFilteredParts().isEmpty())
            return Inventory.getAllParts();
        else
            return Inventory.getFilteredParts();
    }

    public static int generateId() {
        int id = 0;
        return ++id;
        //return (int) (Math.random() * (1000 - 1 + 1) + 1);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //this will allow multiple rows to be selected
        partTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        productTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);


        //Telling which observable list to throw into the program everytime it starts
        partTableView.setItems(Inventory.getAllParts());
        productTableView.setItems(Inventory.getAllProducts());


        //partTableView.setItems(filter("Camera"));

        //Telling it where to place the values in the table
        //Everytime the Observable List is created, all of these fields will be initialized


        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        productIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        System.out.println(generateId());
 /*
        if(search(4))
            System.out.println("W");
        else
            System.out.println("L");


        if(update(90, new InhousePart(4,"new screen",70.00,9,0,10,44444,true)))
            System.out.println("Success !");



        else
            System.out.println("No update >;(");

        if(delete(3))
            System.out.println("bye bye");
        else
            System.out.println("not removed!");


        partTableView.getSelectionModel().select(selectPart(3));
    */


    }


}