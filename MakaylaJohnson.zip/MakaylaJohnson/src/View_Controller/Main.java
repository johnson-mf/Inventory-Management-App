package View_Controller;

import Model.Inhouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/** JAVA DOC IN FOLDER NAME "MakaylaJohnson" Hello, this creates an Inventory app.*/
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 900, 400));
        primaryStage.show();
    }

    /**FUTURE ENHANCEMENT: Add the capabilities to add pictures to each part and product for better visualization*/
    public static void main(String[] args) {
        Part battery = new Inhouse(1,"Battery",50.00,5,0,10,11111);
        Part camera = new Inhouse(2,"Camera",100.00,7,0,10,22222);
       Part cable = new Outsourced(3,"Cable",5.00,1,0,10,"com33333");
        Part screen = new Inhouse(4,"Screen",70.00,9,0,10,44444);
       Part phoneCase = new Outsourced(5,"Case",2.50,10,0,10,"company1");

        Inventory.addPart(battery);
       Inventory.addPart(camera);
        Inventory.addPart(cable);
        Inventory.addPart(screen);
        Inventory.addPart(phoneCase);

        launch(args);
    }
}
