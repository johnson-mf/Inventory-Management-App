package View_Controller;

import Model.Inhouse;
import Model.Inventory;
import Model.Outsourced;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

/**This is this is the Add Part screen. Users and add a part and assign it's fields for the
 * name, stock, max, min, and price. The ID is automatically generated and cannot be changed by the user.
 * When an Inhouse part is selected, the Machine ID field appears. If it is outsourced, the Company name field will appear.
  It will not let you go on if you put the wrong value types in fields.
 Cancelling will prompt a window asking the user whether or not they want to delete their progress.*/
public class AddPartController implements Initializable {
    Stage stage;
    Parent scene;
    // Adding annotations (View-)
    @FXML
    private TextField partIdTxt;

    @FXML
    private TextField partNameTxt;

    @FXML
    private TextField partInventoryTxt;

    @FXML
    private TextField partPriceTxt;

    @FXML
    private TextField partMaxTxt;

    @FXML
    private TextField partMachineIdTxt;

    @FXML
    private RadioButton partInhouseLBtn;

    @FXML
    private ToggleGroup AddPartTG;

    @FXML
    private RadioButton partOutsourcedRBtn;

    @FXML
    private TextField partMinTxt;

    @FXML
    private Label variableLabel;

    @FXML
    private Label warningLabel;
    //RadioButton selectedRadioButton = (RadioButton) AddPartTG.getSelectedToggle();
    //String toggleGroupValue = selectedRadioButton.getText();


    //Go back to main Menu
    @FXML
    void onActionDisplayMainMenu(ActionEvent event) throws IOException {
        //Confirmation dialog box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear text fields, Do you want to continue?");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();

        //If they press OK, we go back to main screen.

        if(result.isPresent() && result.get() == ButtonType.OK) {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }


    //SAVING BUTTON
    @FXML
    void onActionSavePart(ActionEvent event) throws IOException {

        //Taking in text fields and turning them into the appropriate type
     //exception if you enter incorrect data types
    try{

        int id = Inventory.partId++;
        String name = partNameTxt.getText();
        double price = Double.parseDouble(partPriceTxt.getText());
        int stock = Integer.parseInt(partInventoryTxt.getText());
        int min = Integer.parseInt(partMinTxt.getText());
        int max = Integer.parseInt(partMaxTxt.getText());

        if(min <= max && stock <= max && min<= stock){
            if (partInhouseLBtn.isSelected()){
                int machineId = Integer.parseInt(partMachineIdTxt.getText());
                Inventory.addPart(new Inhouse(id,name,price,stock,min,max, machineId));
        }
            else{

            String companyName = partMachineIdTxt.getText();
            Inventory.addPart(new Outsourced(id,name,price,stock,min,max,companyName));
        }
        // go home
            stage = (Stage) ((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
    }
        warningLabel.setText("The inventory number must be a number between the min and max values you enter!");


        }

    catch(NumberFormatException e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Wrong Data Type");
        alert.setContentText("Please enter values that correspond with their fields!");
        alert.showAndWait();
    }
        }

    @FXML
    void onMouseClickInhouse(MouseEvent event) {
        variableLabel.setText("Machine ID:");


    }

    @FXML
    void onMouseClickOutsourced(MouseEvent event) {
        variableLabel.setText("Company Name:");


    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        partInhouseLBtn.setSelected(true);
    }
}
