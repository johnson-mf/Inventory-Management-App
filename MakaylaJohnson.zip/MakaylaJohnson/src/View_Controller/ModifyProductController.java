package View_Controller;

import Model.Inhouse;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**This is the modify part screen. ID will remain the same but the other fields name, stock, max, min, and price can be changed.
        * All parts will appear on the parts list in the first tableview, and the second tableview is to add or subtract parts from the associated parts list. If associated parts were added before,
        * it will show up on the bottom tableview. If a user inputs bad values, the part will not be saved and they will have to change it before continuing. Cancelling will prompt a
        * window asking if the user would like to delete all text fields and go back to the main screen*/

public class ModifyProductController implements Initializable {
    Stage stage;
    Parent scene;
    Product product;

    @FXML
    private TextField productNameTxt;

    @FXML
    private TextField productInventoryTxt;

    @FXML
    private TextField productPriceTxt;

    @FXML
    private TextField productMaxTxt;

    @FXML
    private TextField productMinTxt;

    @FXML
    private Label productIdTxt;


    @FXML
    private TextField partSearchTxt;

    @FXML
    private TableView<Part> partTableView;

    @FXML
    private TableColumn<Part, Integer> partIdCol;

    @FXML
    private TableColumn<Part, String> partNameCol;

    @FXML
    private TableColumn<Part, Integer> partInventoryCol;

    @FXML
    private TableColumn<Part, Double> partPriceCol;

    @FXML
    private TableView<Part> associatedPartTableView;

    @FXML
    private TableColumn<Part, Integer> associatedPartIdCol;

    @FXML
    private TableColumn<Part, String> associatedPartNameCol;

    @FXML
    private TableColumn<Part, Integer> associatedPartInventoryCol;

    @FXML
    private TableColumn<Part, Double> associatedPartPriceCol;

    @FXML
    private Label warningLabel;

    //Setting the text box id in the modify part screen with a pre filled entry
    public void sendProduct(Product product) {

        productIdTxt.setText(String.valueOf(product.getId()));
        productNameTxt.setText(product.getName());
        productInventoryTxt.setText(String.valueOf(product.getStock()));
        productPriceTxt.setText(String.valueOf(product.getPrice()));
        productMaxTxt.setText(String.valueOf(product.getMax()));
        this.product = product;
        productMinTxt.setText(String.valueOf(product.getMin()));
        associatedPartTableView.setItems(product.getAllAssociatedParts());
    }
    @FXML
    void onActionAddPartToProduct(ActionEvent event) {


        // add selected part to list
        Part selectedPart = partTableView.getSelectionModel().getSelectedItem();
        this.product.addAssociatedPart(selectedPart);

        }


    @FXML
    void onActionDisplayMainMenu(ActionEvent event) throws IOException {
        stage = (Stage) ((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void onActionLookupPart(ActionEvent event) {

    }

    @FXML
    void onActionRemoveSelectedPart(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete the associated part?");

        //Gets which button was clicked on the confirmation screen (Ok or Cancel)
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

        }

        // get the parts that have been selected
        ObservableList<Part> selectedRows, allParts;
        allParts = associatedPartTableView.getItems();
        selectedRows = associatedPartTableView.getSelectionModel().getSelectedItems();

        // create a new list to place those parts in

        //ObservableList<Part> associatedPart = FXCollections.observableArrayList();

        for(Part part : selectedRows){
            product.deleteAssociatedPart(part);
        }
    }

    @FXML
    void onActionSaveProduct(ActionEvent event) {

        //Taking in the new  text fields and turning them into the appropriate type
        //exception if you enter incorrect data types
        try {

            //int id = Integer.parseInt(productIdTxt.getText());
            String name = productNameTxt.getText();
            double price = Double.parseDouble(productPriceTxt.getText());
            int stock = Integer.parseInt(productInventoryTxt.getText());
            int min = Integer.parseInt(productMinTxt.getText());
            int max = Integer.parseInt(productMaxTxt.getText());


            if (min <= max && stock <= max && min <= stock) {
                product.setMax(max);
                product.setMin(min);
                product.setName(name);
                product.setStock(stock);


                // then go home
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/View_Controller/Main.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }

            warningLabel.setText("The inventory number must be a number between the min and max values you enter!");
        }

        catch(NumberFormatException | IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Enter real values!");
            alert.showAndWait();
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Telling which observable list to throw into the program everytime it starts
        partTableView.setItems(Inventory.getAllParts());

        //Telling it where to place the values in the table
        //Everytime the Observable List is created, all of these fields will be initialized

        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        //associatedPartTableView.setItems(product.getAssociatedParts());

        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}
